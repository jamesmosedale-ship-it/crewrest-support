CrewRest Support Website

Upload index.html to any simple web host such as:
- GitHub Pages
- Netlify
- Cloudflare Pages
- Carrd custom code
- Your own domain hosting

Recommended App Store Support URL:
https://crewrest.app/support

Before publishing:
1. Replace support@crewrest.app with your real support email address.
2. Change the copyright/company name if needed.
3. Add a full privacy policy page if Apple asks for more detail.
